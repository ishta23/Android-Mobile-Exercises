Javascript and Fabric.Js Library
By Ishta Bhagat and Janki Patel
Spring 2016 CS 341 Final Project 

Our demo is a webpage and the url is: http://ibhagat2.people.uic.edu/341/index.html

The powerpoint presentation is in this folder please do not remove any images or files, 
because the demo will not work otherwise. 

The youtube link for our video is here: 
http://www.youtube.com/watch?v=EXAOZtYaBng

